import { Route, Routes } from "@angular/router";
import { BlackwidowComponent } from "./blackwidow.component";
import { HomeComponent } from "./home.component";
import { HulkComponent } from "./hulk.component";
import { IronmanComponent } from "./ironman.component";
import { NotfoundComponent } from "./notfound.component";

let homeRoute:Route = { path:'', component : HomeComponent };
let ironmanRoute:Route = { path:'ironman', component : IronmanComponent };
let hulkRouteParams:Route = { path:'hulk/:pow', component : HulkComponent };
let blackwidowRoute:Route = { path:'blackwidow', component : BlackwidowComponent };
let thorRoute:Route = { path:'thor', redirectTo:'ironman', pathMatch:'full'};
let wildRoute:Route = { path:'**', component : NotfoundComponent };

export let heroRoutes:Routes = [homeRoute,ironmanRoute,hulkRouteParams,blackwidowRoute,thorRoute,wildRoute];

// 'prefix' or 'full'