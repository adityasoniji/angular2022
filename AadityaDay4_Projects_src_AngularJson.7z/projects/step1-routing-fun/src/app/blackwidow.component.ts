import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blackwidow',
  template: `
  <h2>Black Widow Component</h2>
  `,
  styles: [
  ]
})
export class BlackwidowComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
