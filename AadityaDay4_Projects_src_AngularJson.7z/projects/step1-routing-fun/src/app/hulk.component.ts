import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-hulk',
  template: `
      <h2>Hulk Component</h2>
      <h3>Hulk Power : {{ hulkPower }}</h3>
  `,
  styles: [
  ]
})
export class HulkComponent implements OnInit {
  hulkPower = 0;
  constructor(private ar:ActivatedRoute) { }

  ngOnInit(): void {
    this.hulkPower = this.ar.snapshot.params['pow'];
  }

}
