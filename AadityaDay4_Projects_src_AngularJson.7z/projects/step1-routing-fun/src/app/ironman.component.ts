import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ironman',
  template: `
      <h2>Ironman Component</h2>

      <button (click)="setPowertoHulk()">Power to Hulk</button>
  `,
  styles: [
  ]
})
export class IronmanComponent implements OnInit {

  constructor( private rtr:Router) { }

  ngOnInit(): void {
  }
  setPowertoHulk(){
    this.rtr.navigate(['hulk','66']);
  }
}
