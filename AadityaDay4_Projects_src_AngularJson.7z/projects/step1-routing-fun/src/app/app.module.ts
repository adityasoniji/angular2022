import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HomeComponent } from './home.component';
import { IronmanComponent } from './ironman.component';
import { HulkComponent } from './hulk.component';
import { BlackwidowComponent } from './blackwidow.component';
import { NotfoundComponent } from './notfound.component';
import { RouterModule } from '@angular/router';
import { heroRoutes } from './hero.routes';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    IronmanComponent,
    HulkComponent,
    BlackwidowComponent,
    NotfoundComponent
  ],
  imports: [ BrowserModule, RouterModule.forRoot(heroRoutes), FormsModule ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

// ,{ useHash:true, enableTracing : true}) ],