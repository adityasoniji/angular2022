import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: ``,
  styles: []
})
export class AppComponent {
  title = 'steps';
}
