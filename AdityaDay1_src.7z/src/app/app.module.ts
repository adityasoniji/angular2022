// import { NgModule } from '@angular/core';
// import { BrowserModule } from '@angular/platform-browser';
// import { ChildComp } from './child.component';

// // import { AppComponent } from './app.component';
// import { SecondComp } from './second.component';

// @NgModule({
//   declarations: [ SecondComp, ChildComp ],
//   imports: [ BrowserModule ],
//   providers: [],
//   bootstrap: [ SecondComp ]
// })
// export class AppModule { }


import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { ChildComp } from './child.component';
import { ThirdComp } from './third.component';

// import { AppComponent } from './app.component';
// import { SecondComp } from './second.component';

@NgModule({
  declarations: [ ThirdComp ],
  imports: [ BrowserModule, FormsModule ],
  providers: [],
  bootstrap: [ ThirdComp ]
})
export class AppModule { }