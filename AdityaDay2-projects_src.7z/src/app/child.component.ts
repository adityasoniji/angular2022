import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-child',
  template: `
    <!-- <label for="terms">Show TErms & Conditions</label>
    <input id="terms" type="checkbox" (change)="show=!show">
    {{   show? "true":"false" }}
    <hr>

    <fieldset [hidden = "!show">
<legend> Terms and Conditions </legend>
<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quas obcaecati blanditiis eveniet mollitia cumque libero aspernatur in, hic ex nobis sed excepturi suscipit recusandae atque officiis quam, quibusdam nam vel.
  Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit voluptatum magni sapiente, illo rem molestiae excepturi hic aliquam eum libero eligendi totam eaque voluptas, nam asperiores tempora reiciendis dolor. Minus.
  Lorem, ipsum dolor sit amet consectetur adipisicing elit. Atque temporibus natus dolore quos doloremque. Eum nisi id corrupti atque tenetur, dignissimos dolore dolorum sit, expedita repellat, necessitatibus dolor? Quia, officia?
  Lorem ipsum dolor sit amet consectetur adipisicing elit. Temporibus ullam voluptas numquam molestias. Maxime deserunt voluptatem sapiente exercitationem corrupti quia officiis nulla, aspernatur nihil vel quisquam minus, aliquam odit dolore?
</p>
    </fieldset> -->


    <label for="terms">Show TErms & Conditions</label>
    <input id="terms" type="checkbox" [(ngModel)]="show">
    {{   show ? "true":"false" }}
    <hr>

    <fieldset *ngIf="show">
<legend> Terms and Conditions </legend>
<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quas obcaecati blanditiis eveniet mollitia cumque libero aspernatur in, hic ex nobis sed excepturi suscipit recusandae atque officiis quam, quibusdam nam vel.
  Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit voluptatum magni sapiente, illo rem molestiae excepturi hic aliquam eum libero eligendi totam eaque voluptas, nam asperiores tempora reiciendis dolor. Minus.
  Lorem, ipsum dolor sit amet consectetur adipisicing elit. Atque temporibus natus dolore quos doloremque. Eum nisi id corrupti atque tenetur, dignissimos dolore dolorum sit, expedita repellat, necessitatibus dolor? Quia, officia?
  Lorem ipsum dolor sit amet consectetur adipisicing elit. Temporibus ullam voluptas numquam molestias. Maxime deserunt voluptatem sapiente exercitationem corrupti quia officiis nulla, aspernatur nihil vel quisquam minus, aliquam odit dolore?
</p>
</fieldset>
<input #ti1 type="text">
<button (click)="addHero(ti1.value)">Add hero</button>
<p>{{justiceleague.toString()}}</p>
<hr>
<ol>
  <li *ngFor= "let hero of justiceleague"> {{hero}} </li>
</ol>
<hr>

<input type="range" min="0" max="10" [(ngModel)]="power"> Power is {{power}}
<ul [ngSwitch]="power">
  <li *ngSwitchCase="6">Heros power is 6| recovered</li>
  <li *ngSwitchCase="7">Heros power is 7| ready to fight</li>
  <li *ngSwitchCase="8">Heros power is 8| strong</li>
  <li *ngSwitchCase="9">Heros power is 9| super strong </li>
  <li *ngSwitchCase="10">Heros power is 10| Undefeatable</li>
  <li *ngSwitchDefault>Heros power is less than 6| needs rest</li>
</ul>
<p ngNonBindable>{{ lets take a break }}</p>
   <hr>
   <div class="box blueBorder">
     Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ducimus nulla consequuntur laboriosam odio vero dicta repudiandae blanditiis dolorum ea iure reiciendis, laudantium ipsam, alias aliquid sed molestias inventore? Similique, unde!
   </div>
   <div [class]="mystyle">
     Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ducimus nulla consequuntur laboriosam odio vero dicta repudiandae blanditiis dolorum ea iure reiciendis, laudantium ipsam, alias aliquid sed molestias inventore? Similique, unde!
   </div>
   <div [class.box]="show">
     Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ducimus nulla consequuntur laboriosam odio vero dicta repudiandae blanditiis dolorum ea iure reiciendis, laudantium ipsam, alias aliquid sed molestias inventore? Similique, unde!
   </div>
   <div [ngClass]="['box','redBorder']">
     Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ducimus nulla consequuntur laboriosam odio vero dicta repudiandae blanditiis dolorum ea iure reiciendis, laudantium ipsam, alias aliquid sed molestias inventore? Similique, unde!
   </div>
   <div [ngClass]="{'box' : show, 'redBorder' : power > 6}">
     Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ducimus nulla consequuntur laboriosam odio vero dicta repudiandae blanditiis dolorum ea iure reiciendis, laudantium ipsam, alias aliquid sed molestias inventore? Similique, unde!
   </div>
  `,
  styles: [`
  .box{
      width : 200px;
      padding : 10px;
      margin : 10px auto;
      background-color : silver;
      text-align : justify;
    }
    .redBorder{
      border : 10px solid red;
      border-radius : 20px;
    }
    .blueBorder{
      border : 10px solid blue;
      border-radius : 20px;
    }
  `
  ]
})
export class ChildComponent  {
show = false;
power=0;
mystyle = 'box';
  justiceleague=['BAtman']

addHero(val:any){
  this.justiceleague.push(val);
}

}
