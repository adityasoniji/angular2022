import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <h1> Welcome Citi</h1>
  <app-child></app-child>
  `
  
})
export class AppComponent {
  title = 'steps';
}
