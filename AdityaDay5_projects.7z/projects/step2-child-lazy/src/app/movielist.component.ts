import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-movielist',
  template: `
    <p>
      movielist works!
    </p>
  `,
  styles: []
})
export class MovielistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
