import { Component } from '@angular/core';
import { UserService } from './users.service';

@Component({
  selector: 'app-root',
  template: `
    <h1>Users List</h1>
    <hr>
    <ol>
      <li *ngFor="let user of usersarray">{{ user.name }}</li>
    </ol>
  `,
  styles: []
})
export class AppComponent {
  title = 'step3-http';
  usersarray:any;
  constructor(private us:UserService){}
  ngOnInit(){
    this.us.getuserlist().subscribe(res => this.usersarray = res);
  }
}
