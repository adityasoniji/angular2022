import { NgModule } from "@angular/core";
import { CitiComp } from "./citi.component";
import { CitiDirective } from "./citi.directive";
import { GenPipe } from "./gen.pipe";

@NgModule({
    // components, directives, pipes
    declarations : [ CitiDirective, GenPipe, CitiComp ],
    // export components, directives, pipes, modules, services
    exports : [ CitiDirective, GenPipe, CitiComp ]
})
export class CitiModule{

}
// how to create a library