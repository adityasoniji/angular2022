import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { CitiModule } from './citi.module';


@NgModule({
  // components, directives, pipes
  declarations: [ AppComponent ],
  // additional modules
  imports: [ BrowserModule, CitiModule ],
  // services
  providers: [],
  // attach main component
  bootstrap: [AppComponent]
})
export class AppModule { }
