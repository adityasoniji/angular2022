import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <div class="container">
  <h1>Directives and Pipes</h1>
      <app-header></app-header>
   <hr>
      <app-grid></app-grid>
   `
   ,
  styles: [
  ]
})
export class AppComponent {

}
