import { Component, Input } from '@angular/core';
import { HeroService } from './hero.service';

@Component({
  selector: 'app-grid',
  template: `
  <h2>{{ "Gridheader "+  appversion }}</h2>
   <table class="table table-responsive table-striped table-hover table-bordered">
     <thead class="table-dark">
       <tr>
         <th>Sl #</th>
         <th>Title</th>
         <th>Full Name</th>
         <th>Poster</th>
         <th>City</th>
         <th>Ticket Price</th>
         <th>Release Date</th>
         <th>Movies</th>
       </tr>
     </thead>
     <tbody>
       <tr *ngFor="let hero of heroes">
         <td>{{ hero.sl }}</td>
         <td>{{ hero.title | uppercase | lowercase | titlecase }}</td>
         <!-- {{ hero.gender === 'male' ? 'Mr ' : 'Miss '}} -->
         <td>{{ hero.firstname+" "+hero.lastname | gen : hero.gender }}</td>
         <td>
           <img class="rounded" width="60" [src]="hero.poster" [alt]="hero.title">
         </td>
         <td>{{ hero.city }}</td>
         <td>{{ hero.ticketprice | currency : 'INR' : 'symbol' : '3.2-4' }}</td>
         <td>{{ hero.releasedate | date : 'dd / MMMM / yyyy' }}</td>
         <td>
            <img style="margin: 2px;" *ngFor="let movie of hero.movieslist" width="40" [src]="movie.poster" [alt]="movie.title">
         </td>
       </tr>
     </tbody>
   </table>
  `,
  styles: [
  ]
})
export class GridComponent {
  heroes:any;
  appversion:any;
  // hs:HeroService = new HeroService();

  constructor(private hs:HeroService){
    this.heroes = this.hs.getHero();
    this.appversion = this.hs.getVersion();
  }
}
