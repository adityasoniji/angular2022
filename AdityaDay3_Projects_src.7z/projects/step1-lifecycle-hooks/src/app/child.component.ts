import { AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, DoCheck, Input, OnChanges, OnDestroy, OnInit } from '@angular/core';

@Component({
  selector: 'app-child',
  template: `
   <h2>Child Component</h2>
   <h3>Power : {{ power }}</h3>
  `,
  styles: [
  ]
})
export class ChildComponent implements  OnInit, 
                                        OnChanges,
                                        DoCheck,
                                        AfterContentInit,
                                        AfterContentChecked,
                                        AfterViewInit,
                                        AfterViewChecked,
                                        OnDestroy{
  // @Input() power = 0;
  power = 0;
  constructor() { 
    console.log("Child Component's constructor was called");
  }
  
  ngOnInit(): void {
    console.log("Child Component's ngOnInit was called");
  }
  ngOnChanges(args:any): void {
   // console.log(arguments.length)
    console.log(args);
    if(args.power.currentValue > 5){
      this.power = 0;
    }
    console.log("Child Component's ngOnChanges was called");
  }
  ngDoCheck(): void {
    console.log("Child Component's ngDoCheck was called");
  }
  ngAfterViewInit(): void {
    console.log("Child Component's ngAfterViewInit was called");
  }
  ngAfterViewChecked(): void {
    console.log("Child Component's ngAfterViewChecked was called");
  }
  ngAfterContentInit(): void {
    console.log("Child Component's ngAfterContentInit was called");
  }
  ngAfterContentChecked(): void {
    console.log("Child Component's ngAfterContentChecked was called");
  }
  ngOnDestroy(): void {
    console.log("Child Component's ngOnDestroy was called");
  }
  increasePower(){
    this.power++;
  }
  decreasePower(){
    this.power--;
  }
}
